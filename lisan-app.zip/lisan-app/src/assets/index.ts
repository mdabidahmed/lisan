/**
 * Lisan visual asset registry.
 *
 * Every binary asset is imported through Vite, so the emitted URLs are
 * content-hashed and safe to cache immutably. The only hard-coded paths are the
 * favicon / PWA / share-card files under `brandUrls`, which must keep stable
 * URLs because they are referenced from `index.html` and the web app manifest.
 *
 * Theming the SVGs
 * ----------------
 * The hand-authored SVGs in `illustrations` and `decorative` paint through CSS
 * custom properties with on-brand fallbacks, so they render correctly as plain
 * `<img>` tags and recolour when inlined. Override these on an ancestor to
 * retheme them (for example for dark mode):
 *
 *   --lisan-pri       #1769FF   primary strokes and accents
 *   --lisan-soft      #BBD5FF   mid tint: secondary shapes, shadows
 *   --lisan-bg        #EAF2FF   pale surfaces ("paper")
 *   --lisan-surface   #FFFFFF   knockouts and highlights
 *   --lisan-ink       #172033   text-weight marks
 *   --lisan-success   #12B76A   --lisan-warning #F79009   --lisan-error #F04438
 *   --lisan-info      #2E90FA   --lisan-warning-deep #DC6803
 *   --lisan-leaf / --lisan-leaf-deep / --lisan-leaf-light   leaf flourish greens
 *   --lisan-blob-from / --lisan-blob-to                     quote blob gradient
 *   --lisan-scrim / --lisan-scrim-ink                       hero overlay
 *   --lisan-pattern                                         geometric pattern tile
 *   --lisan-wordmark / --lisan-wordmark-sub                 lockup type colours
 *
 * This file is generated artwork metadata, but it is plain source: edit freely.
 */

// Brand marks — vector, imported through Vite so they are content-hashed.
import logoMarkSrc from './brand/logo-mark.svg';
import logoLockupSrc from './brand/logo-lockup.svg';
import logoMonoSrc from './brand/logo-mono.svg';

// Home hero — responsive raster set.
import heroAvif1600 from './hero/hero-1600.avif';
import heroAvif960 from './hero/hero-960.avif';
import heroWebp1600 from './hero/hero-1600.webp';
import heroWebp960 from './hero/hero-960.webp';
import heroJpg1600 from './hero/hero-1600.jpg';

// Category art — 256w + 128w, AVIF with WebP fallback.
import catBasicsAvif from './categories/basics.avif';
import catBasicsWebp from './categories/basics.webp';
import catBasicsAvif128 from './categories/basics-128.avif';
import catBasicsWebp128 from './categories/basics-128.webp';
import catNumbersTimeAvif from './categories/numbers-time.avif';
import catNumbersTimeWebp from './categories/numbers-time.webp';
import catNumbersTimeAvif128 from './categories/numbers-time-128.avif';
import catNumbersTimeWebp128 from './categories/numbers-time-128.webp';
import catFamilyPeopleAvif from './categories/family-people.avif';
import catFamilyPeopleWebp from './categories/family-people.webp';
import catFamilyPeopleAvif128 from './categories/family-people-128.avif';
import catFamilyPeopleWebp128 from './categories/family-people-128.webp';
import catFoodDiningAvif from './categories/food-dining.avif';
import catFoodDiningWebp from './categories/food-dining.webp';
import catFoodDiningAvif128 from './categories/food-dining-128.avif';
import catFoodDiningWebp128 from './categories/food-dining-128.webp';
import catHomeRoomsAvif from './categories/home-rooms.avif';
import catHomeRoomsWebp from './categories/home-rooms.webp';
import catHomeRoomsAvif128 from './categories/home-rooms-128.avif';
import catHomeRoomsWebp128 from './categories/home-rooms-128.webp';
import catShoppingMoneyAvif from './categories/shopping-money.avif';
import catShoppingMoneyWebp from './categories/shopping-money.webp';
import catShoppingMoneyAvif128 from './categories/shopping-money-128.avif';
import catShoppingMoneyWebp128 from './categories/shopping-money-128.webp';
import catTransportTravelAvif from './categories/transport-travel.avif';
import catTransportTravelWebp from './categories/transport-travel.webp';
import catTransportTravelAvif128 from './categories/transport-travel-128.avif';
import catTransportTravelWebp128 from './categories/transport-travel-128.webp';
import catDailyLifeAvif from './categories/daily-life.avif';
import catDailyLifeWebp from './categories/daily-life.webp';
import catDailyLifeAvif128 from './categories/daily-life-128.avif';
import catDailyLifeWebp128 from './categories/daily-life-128.webp';
import catVerbsAvif from './categories/verbs.avif';
import catVerbsWebp from './categories/verbs.webp';
import catVerbsAvif128 from './categories/verbs-128.avif';
import catVerbsWebp128 from './categories/verbs-128.webp';
import catAdjectivesAvif from './categories/adjectives.avif';
import catAdjectivesWebp from './categories/adjectives.webp';
import catAdjectivesAvif128 from './categories/adjectives-128.avif';
import catAdjectivesWebp128 from './categories/adjectives-128.webp';
import catSchoolEducationAvif from './categories/school-education.avif';
import catSchoolEducationWebp from './categories/school-education.webp';
import catSchoolEducationAvif128 from './categories/school-education-128.avif';
import catSchoolEducationWebp128 from './categories/school-education-128.webp';
import catWorkProfessionsAvif from './categories/work-professions.avif';
import catWorkProfessionsWebp from './categories/work-professions.webp';
import catWorkProfessionsAvif128 from './categories/work-professions-128.avif';
import catWorkProfessionsWebp128 from './categories/work-professions-128.webp';
import catNatureAnimalsAvif from './categories/nature-animals.avif';
import catNatureAnimalsWebp from './categories/nature-animals.webp';
import catNatureAnimalsAvif128 from './categories/nature-animals-128.avif';
import catNatureAnimalsWebp128 from './categories/nature-animals-128.webp';
import catHealthBodyAvif from './categories/health-body.avif';
import catHealthBodyWebp from './categories/health-body.webp';
import catHealthBodyAvif128 from './categories/health-body-128.avif';
import catHealthBodyWebp128 from './categories/health-body-128.webp';
import catTechnologyMediaAvif from './categories/technology-media.avif';
import catTechnologyMediaWebp from './categories/technology-media.webp';
import catTechnologyMediaAvif128 from './categories/technology-media-128.avif';
import catTechnologyMediaWebp128 from './categories/technology-media-128.webp';
import catAbstractAcademicAvif from './categories/abstract-academic.avif';
import catAbstractAcademicWebp from './categories/abstract-academic.webp';
import catAbstractAcademicAvif128 from './categories/abstract-academic-128.avif';
import catAbstractAcademicWebp128 from './categories/abstract-academic-128.webp';
import catExpressionsIdiomsAvif from './categories/expressions-idioms.avif';
import catExpressionsIdiomsWebp from './categories/expressions-idioms.webp';
import catExpressionsIdiomsAvif128 from './categories/expressions-idioms-128.avif';
import catExpressionsIdiomsWebp128 from './categories/expressions-idioms-128.webp';

// Word art — 320w + 160w, AVIF with WebP fallback.
import wordEngineerAvif from './words/engineer.avif';
import wordEngineerWebp from './words/engineer.webp';
import wordEngineerAvif160 from './words/engineer-160.avif';
import wordEngineerWebp160 from './words/engineer-160.webp';
import wordTeacherAvif from './words/teacher.avif';
import wordTeacherWebp from './words/teacher.webp';
import wordTeacherAvif160 from './words/teacher-160.avif';
import wordTeacherWebp160 from './words/teacher-160.webp';
import wordDoctorAvif from './words/doctor.avif';
import wordDoctorWebp from './words/doctor.webp';
import wordDoctorAvif160 from './words/doctor-160.avif';
import wordDoctorWebp160 from './words/doctor-160.webp';
import wordStudentAvif from './words/student.avif';
import wordStudentWebp from './words/student.webp';
import wordStudentAvif160 from './words/student-160.avif';
import wordStudentWebp160 from './words/student-160.webp';
import wordComputerAvif from './words/computer.avif';
import wordComputerWebp from './words/computer.webp';
import wordComputerAvif160 from './words/computer-160.avif';
import wordComputerWebp160 from './words/computer-160.webp';
import wordNurseAvif from './words/nurse.avif';
import wordNurseWebp from './words/nurse.webp';
import wordNurseAvif160 from './words/nurse-160.avif';
import wordNurseWebp160 from './words/nurse-160.webp';
import wordAppleAvif from './words/apple.avif';
import wordAppleWebp from './words/apple.webp';
import wordAppleAvif160 from './words/apple-160.avif';
import wordAppleWebp160 from './words/apple-160.webp';
import wordMotherAvif from './words/mother.avif';
import wordMotherWebp from './words/mother.webp';
import wordMotherAvif160 from './words/mother-160.avif';
import wordMotherWebp160 from './words/mother-160.webp';
import wordFatherAvif from './words/father.avif';
import wordFatherWebp from './words/father.webp';
import wordFatherAvif160 from './words/father-160.avif';
import wordFatherWebp160 from './words/father-160.webp';
import wordBrotherAvif from './words/brother.avif';
import wordBrotherWebp from './words/brother.webp';
import wordBrotherAvif160 from './words/brother-160.avif';
import wordBrotherWebp160 from './words/brother-160.webp';
import wordSisterAvif from './words/sister.avif';
import wordSisterWebp from './words/sister.webp';
import wordSisterAvif160 from './words/sister-160.avif';
import wordSisterWebp160 from './words/sister-160.webp';
import wordHouseAvif from './words/house.avif';
import wordHouseWebp from './words/house.webp';
import wordHouseAvif160 from './words/house-160.avif';
import wordHouseWebp160 from './words/house-160.webp';
import wordDoorAvif from './words/door.avif';
import wordDoorWebp from './words/door.webp';
import wordDoorAvif160 from './words/door-160.avif';
import wordDoorWebp160 from './words/door-160.webp';
import wordChairAvif from './words/chair.avif';
import wordChairWebp from './words/chair.webp';
import wordChairAvif160 from './words/chair-160.avif';
import wordChairWebp160 from './words/chair-160.webp';
import wordBookAvif from './words/book.avif';
import wordBookWebp from './words/book.webp';
import wordBookAvif160 from './words/book-160.avif';
import wordBookWebp160 from './words/book-160.webp';
import wordWaterAvif from './words/water.avif';
import wordWaterWebp from './words/water.webp';
import wordWaterAvif160 from './words/water-160.avif';
import wordWaterWebp160 from './words/water-160.webp';
import wordBreadAvif from './words/bread.avif';
import wordBreadWebp from './words/bread.webp';
import wordBreadAvif160 from './words/bread-160.avif';
import wordBreadWebp160 from './words/bread-160.webp';
import wordMilkAvif from './words/milk.avif';
import wordMilkWebp from './words/milk.webp';
import wordMilkAvif160 from './words/milk-160.avif';
import wordMilkWebp160 from './words/milk-160.webp';
import wordTeaAvif from './words/tea.avif';
import wordTeaWebp from './words/tea.webp';
import wordTeaAvif160 from './words/tea-160.avif';
import wordTeaWebp160 from './words/tea-160.webp';
import wordCarAvif from './words/car.avif';
import wordCarWebp from './words/car.webp';
import wordCarAvif160 from './words/car-160.avif';
import wordCarWebp160 from './words/car-160.webp';
import wordCatAvif from './words/cat.avif';
import wordCatWebp from './words/cat.webp';
import wordCatAvif160 from './words/cat-160.avif';
import wordCatWebp160 from './words/cat-160.webp';
import wordBirdAvif from './words/bird.avif';
import wordBirdWebp from './words/bird.webp';
import wordBirdAvif160 from './words/bird-160.avif';
import wordBirdWebp160 from './words/bird-160.webp';
import wordTreeAvif from './words/tree.avif';
import wordTreeWebp from './words/tree.webp';
import wordTreeAvif160 from './words/tree-160.avif';
import wordTreeWebp160 from './words/tree-160.webp';
import wordSunAvif from './words/sun.avif';
import wordSunWebp from './words/sun.webp';
import wordSunAvif160 from './words/sun-160.avif';
import wordSunWebp160 from './words/sun-160.webp';
import wordMoonAvif from './words/moon.avif';
import wordMoonWebp from './words/moon.webp';
import wordMoonAvif160 from './words/moon-160.avif';
import wordMoonWebp160 from './words/moon-160.webp';

// UI state illustrations — flat SVG, themeable through CSS custom properties.
import emptySearchSrc from './illustrations/empty-search.svg';
import emptyBookmarksSrc from './illustrations/empty-bookmarks.svg';
import emptyProgressSrc from './illustrations/empty-progress.svg';
import errorGenericSrc from './illustrations/error-generic.svg';
import offlineSrc from './illustrations/offline.svg';
import notFoundSrc from './illustrations/not-found-404.svg';
import quizCompleteSrc from './illustrations/quiz-complete.svg';

// Decorative flourishes — purely presentational.
import leafFlourishSrc from './decorative/leaf-flourish.svg';
import quoteBlobSrc from './decorative/quote-blob.svg';
import heroGradientOverlaySrc from './decorative/hero-gradient-overlay.svg';
import patternTileSrc from './decorative/pattern-tile.svg';

// Quiz feedback cues — 16-bit mono WAV, generated by ./sounds/generate-sounds.mjs.
import correctSrc from './sounds/correct.wav';
import incorrectSrc from './sounds/incorrect.wav';
import completeSrc from './sounds/complete.wav';

/** A `srcset`-ready set of candidate strings, one per source type. */
export interface ResponsiveSources {
  readonly avif?: string;
  readonly webp: string;
  readonly fallback?: string;
}

/** A raster image with its modern and fallback encodings plus display metadata. */
export interface ImageAsset {
  /** AVIF URL — smallest, offer first in a `<picture>`. */
  readonly avif?: string;
  /** WebP URL — universally supported baseline. */
  readonly webp: string;
  /** JPEG/PNG URL for very old clients. */
  readonly fallback?: string;
  readonly width: number;
  readonly height: number;
  /** Base64 `data:` URI of a 8-16px blurred copy, for instant paint. */
  readonly lqip?: string;
  readonly alt: string;
  /** Present when the asset ships at more than one width. */
  readonly srcSet?: ResponsiveSources;
  /** `true` when the image adds no information and `alt` is intentionally empty. */
  readonly decorative?: boolean;
}

/** A vector asset. `width`/`height` are the intrinsic viewBox dimensions. */
export interface VectorAsset {
  readonly src: string;
  readonly width: number;
  readonly height: number;
  readonly alt: string;
  readonly decorative?: boolean;
}

/** A short interaction cue. */
export interface SoundAsset {
  readonly src: string;
  /** Accessible description, for announcing the cue in a live region. */
  readonly label: string;
  readonly durationMs: number;
}

/* -------------------------------------------------------------- brand --- */

export const brand = {
  logoMark: { src: logoMarkSrc, width: 48, height: 48, alt: 'Lisan' },
  logoLockup: {
    src: logoLockupSrc,
    width: 203,
    height: 48,
    alt: 'Lisan — Learn Arabic, Grow Closer',
  },
  logoMono: { src: logoMonoSrc, width: 48, height: 48, alt: 'Lisan' },
} as const satisfies Record<string, VectorAsset>;

/**
 * Files served verbatim from `public/brand/`. These deliberately bypass Vite
 * hashing: `index.html`, the web app manifest and social scrapers need URLs
 * that never change.
 */
export const brandUrls = {
  faviconSvg: '/brand/favicon.svg',
  faviconIco: '/brand/favicon.ico',
  favicon32: '/brand/favicon-32.png',
  favicon16: '/brand/favicon-16.png',
  appleTouchIcon: '/brand/apple-touch-icon.png',
  pwa192: '/brand/pwa-192.png',
  pwa512: '/brand/pwa-512.png',
  pwaMaskable512: '/brand/pwa-maskable-512.png',
  ogImage: '/brand/og-image.png',
} as const;

/* --------------------------------------------------------------- hero --- */

export const hero: ImageAsset = {
  avif: heroAvif1600,
  webp: heroWebp1600,
  fallback: heroJpg1600,
  width: 1600,
  height: 900,
  lqip: 'data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAACwAQCdASoQAAkABABsJbACdAENRdygAP7niA+6/enSQUFAar3ZB4hN3sM+mhHynY58jl7powAAAA==',
  alt: 'A grand mosque with blue domes and minarets at golden hour, framed by palm trees above a calm bay with a distant city skyline',
  srcSet: {
    avif: `${heroAvif960} 960w, ${heroAvif1600} 1600w`,
    webp: `${heroWebp960} 960w, ${heroWebp1600} 1600w`,
    fallback: `${heroJpg1600} 1600w`,
  },
};

/* ----------------------------------------------------------- category --- */

/** Category ids that have real artwork. Anything absent falls back in code. */
export const categoryArtIds = [
  'basics',
  'numbers-time',
  'family-people',
  'food-dining',
  'home-rooms',
  'shopping-money',
  'transport-travel',
  'daily-life',
  'verbs',
  'adjectives',
  'school-education',
  'work-professions',
  'nature-animals',
  'health-body',
  'technology-media',
  'abstract-academic',
  'expressions-idioms',
] as const;

export type CategoryArtId = (typeof categoryArtIds)[number];

export const categoryArt: Partial<Record<string, ImageAsset>> = {
  basics: {
    avif: catBasicsAvif,
    webp: catBasicsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAADQAQCdASoIAAgABABsJagCdAD0ebhVAAD+7d3UyWlpLCwqEMEqZeBkn6ms6AAA',
    alt: 'An open waving hand beside a speech bubble',
    srcSet: {
      avif: `${catBasicsAvif128} 128w, ${catBasicsAvif} 256w`,
      webp: `${catBasicsWebp128} 128w, ${catBasicsWebp} 256w`,
    },
  },
  'numbers-time': {
    avif: catNumbersTimeAvif,
    webp: catNumbersTimeWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAADQAQCdASoIAAgABABsJQBOgCHgIGm6AAD+5+sxq+CgJx3DZ6lrALQQhwy+ibAA',
    alt: 'A round wall clock beside stacked counting blocks',
    srcSet: {
      avif: `${catNumbersTimeAvif128} 128w, ${catNumbersTimeAvif} 256w`,
      webp: `${catNumbersTimeWebp128} 128w, ${catNumbersTimeWebp} 256w`,
    },
  },
  'family-people': {
    avif: catFamilyPeopleAvif,
    webp: catFamilyPeopleWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACwAQCdASoIAAgABABsJagCdAD0bn6gAP7n7AKqKjrucySzMomPRpqVorKxQAAA',
    alt: 'A family of three standing together',
    srcSet: {
      avif: `${catFamilyPeopleAvif128} 128w, ${catFamilyPeopleAvif} 256w`,
      webp: `${catFamilyPeopleWebp128} 128w, ${catFamilyPeopleWebp} 256w`,
    },
  },
  'food-dining': {
    avif: catFoodDiningAvif,
    webp: catFoodDiningWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRkIAAABXRUJQVlA4IDYAAADQAQCdASoIAAgABABsJbACdADze8J1AAD+15N3GJqLgLJGhnBKlbnr6dn39m/dE0wNftZgAAA=',
    alt: 'A bowl of fresh vegetables beside flatbread',
    srcSet: {
      avif: `${catFoodDiningAvif128} 128w, ${catFoodDiningAvif} 256w`,
      webp: `${catFoodDiningWebp128} 128w, ${catFoodDiningWebp} 256w`,
    },
  },
  'home-rooms': {
    avif: catHomeRoomsAvif,
    webp: catHomeRoomsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAABwAQCdASoIAAgABABsJZACdAFAAAD+7mv5eBt7lvsiC6jhNDjCMNWwAAA=',
    alt: 'A house with a blue roof and garden shrubs',
    srcSet: {
      avif: `${catHomeRoomsAvif128} 128w, ${catHomeRoomsAvif} 256w`,
      webp: `${catHomeRoomsWebp128} 128w, ${catHomeRoomsWebp} 256w`,
    },
  },
  'shopping-money': {
    avif: catShoppingMoneyAvif,
    webp: catShoppingMoneyWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAACwAQCdASoIAAgABABsJZgCdAD0ebYEAP7iUkJnE2aR1j73zxjoADSkR172R6B9m4cWNiRXqAAAAA==',
    alt: 'A shopping bag beside stacked coins and a banknote',
    srcSet: {
      avif: `${catShoppingMoneyAvif128} 128w, ${catShoppingMoneyAvif} 256w`,
      webp: `${catShoppingMoneyWebp128} 128w, ${catShoppingMoneyWebp} 256w`,
    },
  },
  'transport-travel': {
    avif: catTransportTravelAvif,
    webp: catTransportTravelWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRj4AAABXRUJQVlA4IDIAAADwAQCdASoIAAgABABsJagCdH8AGAdpXQAA/ucTWXOVFqI1HFtqNmVTteHDSB9qkxAAAA==',
    alt: 'A suitcase with an aeroplane flying overhead',
    srcSet: {
      avif: `${catTransportTravelAvif128} 128w, ${catTransportTravelAvif} 256w`,
      webp: `${catTransportTravelWebp128} 128w, ${catTransportTravelWebp} 256w`,
    },
  },
  'daily-life': {
    avif: catDailyLifeAvif,
    webp: catDailyLifeWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADwAQCdASoIAAgABABsJbACdAD0uMHBGAAA/u1hbh5qBcFBKU6P+2EMEQQCL5TgAAA=',
    alt: 'A steaming mug beside a toothbrush in a cup',
    srcSet: {
      avif: `${catDailyLifeAvif128} 128w, ${catDailyLifeAvif} 256w`,
      webp: `${catDailyLifeWebp128} 128w, ${catDailyLifeWebp} 256w`,
    },
  },
  verbs: {
    avif: catVerbsAvif,
    webp: catVerbsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRkAAAABXRUJQVlA4IDQAAABwAQCdASoIAAgABABsJbACdAFAAAD+7vkY7Bqn/63CxtCcdE3qFwiWxtj2fxPchaiT5QAA',
    alt: 'A person running, with motion lines behind them',
    srcSet: {
      avif: `${catVerbsAvif128} 128w, ${catVerbsAvif} 256w`,
      webp: `${catVerbsWebp128} 128w, ${catVerbsWebp} 256w`,
    },
  },
  adjectives: {
    avif: catAdjectivesAvif,
    webp: catAdjectivesWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjgAAABXRUJQVlA4ICwAAACwAQCdASoIAAgABABsJQBOgCHe8Uv4AP7gnl59dJHXATQY/qGwhVec0YAAAA==',
    alt: 'An artist’s palette with a brush and blobs of paint',
    srcSet: {
      avif: `${catAdjectivesAvif128} 128w, ${catAdjectivesAvif} 256w`,
      webp: `${catAdjectivesWebp128} 128w, ${catAdjectivesWebp} 256w`,
    },
  },
  'school-education': {
    avif: catSchoolEducationAvif,
    webp: catSchoolEducationWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRj4AAABXRUJQVlA4IDIAAACwAQCdASoIAAgABABsJYgCdADyfvaAAP6breKuzIeKJalMS/+MwdkYli50OJHuT9EYAA==',
    alt: 'A graduation cap resting on a stack of books with a pencil',
    srcSet: {
      avif: `${catSchoolEducationAvif128} 128w, ${catSchoolEducationAvif} 256w`,
      webp: `${catSchoolEducationWebp128} 128w, ${catSchoolEducationWebp} 256w`,
    },
  },
  'work-professions': {
    avif: catWorkProfessionsAvif,
    webp: catWorkProfessionsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRkIAAABXRUJQVlA4IDYAAADQAQCdASoIAAgABABsJbACdAD0sRa7gAD+tCqb3P4SR7TQJXnov195cEbVzysgwOIpWrMIAAA=',
    alt: 'A leather briefcase beside a hard hat',
    srcSet: {
      avif: `${catWorkProfessionsAvif128} 128w, ${catWorkProfessionsAvif} 256w`,
      webp: `${catWorkProfessionsWebp128} 128w, ${catWorkProfessionsWebp} 256w`,
    },
  },
  'nature-animals': {
    avif: catNatureAnimalsAvif,
    webp: catNatureAnimalsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAABwAQCdASoIAAgABABsJYgCdAFAAAD+70vmT4vHXSPL5G6LWi+IglZQCf9pGroAAAA=',
    alt: 'A mountain lake landscape with trees and a clear sky',
    srcSet: {
      avif: `${catNatureAnimalsAvif128} 128w, ${catNatureAnimalsAvif} 256w`,
      webp: `${catNatureAnimalsWebp128} 128w, ${catNatureAnimalsWebp} 256w`,
    },
  },
  'health-body': {
    avif: catHealthBodyAvif,
    webp: catHealthBodyWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjgAAABXRUJQVlA4ICwAAACwAQCdASoIAAgABABsJZgCdAEO/gLsAP7gyzpmhSyVsf4g9dPuKRaTKoAAAA==',
    alt: 'A heart wrapped in a stethoscope',
    srcSet: {
      avif: `${catHealthBodyAvif128} 128w, ${catHealthBodyAvif} 256w`,
      webp: `${catHealthBodyWebp128} 128w, ${catHealthBodyWebp} 256w`,
    },
  },
  'technology-media': {
    avif: catTechnologyMediaAvif,
    webp: catTechnologyMediaWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAgABABsJQBOgCB/QsY3QAD+aLj3u2udD4G9FwaxzSBxWTvR65OAAAA=',
    alt: 'A laptop and phone with a wireless signal',
    srcSet: {
      avif: `${catTechnologyMediaAvif128} 128w, ${catTechnologyMediaAvif} 256w`,
      webp: `${catTechnologyMediaWebp128} 128w, ${catTechnologyMediaWebp} 256w`,
    },
  },
  'abstract-academic': {
    avif: catAbstractAcademicAvif,
    webp: catAbstractAcademicWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRjIAAABXRUJQVlA4ICYAAABQAQCdASoIAAgABABsJQBOgC6gAP7v9s9VN7QrtRUQFV3uJo2IAA==',
    alt: 'A glowing lightbulb surrounded by floating geometric shapes',
    srcSet: {
      avif: `${catAbstractAcademicAvif128} 128w, ${catAbstractAcademicAvif} 256w`,
      webp: `${catAbstractAcademicWebp128} 128w, ${catAbstractAcademicWebp} 256w`,
    },
  },
  'expressions-idioms': {
    avif: catExpressionsIdiomsAvif,
    webp: catExpressionsIdiomsWebp,
    width: 256,
    height: 256,
    lqip: 'data:image/webp;base64,UklGRkYAAABXRUJQVlA4IDoAAAAQAgCdASoIAAgABABsJZgCdEf/gbhk6PYAAP7h64PnyTMZJWoc/EZLJyPS6EI3B5Vhqs0rkI/mrSwA',
    alt: 'Two overlapping speech bubbles',
    srcSet: {
      avif: `${catExpressionsIdiomsAvif128} 128w, ${catExpressionsIdiomsAvif} 256w`,
      webp: `${catExpressionsIdiomsWebp128} 128w, ${catExpressionsIdiomsWebp} 256w`,
    },
  },
};

/* --------------------------------------------------------------- word --- */

/** Word ids that have real artwork. Anything absent falls back in code. */
export const wordArtIds = [
  'engineer',
  'teacher',
  'doctor',
  'student',
  'computer',
  'nurse',
  'apple',
  'mother',
  'father',
  'brother',
  'sister',
  'house',
  'door',
  'chair',
  'book',
  'water',
  'bread',
  'milk',
  'tea',
  'car',
  'cat',
  'bird',
  'tree',
  'sun',
  'moon',
] as const;

export type WordArtId = (typeof wordArtIds)[number];

export const wordArt: Partial<Record<string, ImageAsset>> = {
  engineer: {
    avif: wordEngineerAvif,
    webp: wordEngineerWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRj4AAABXRUJQVlA4IDIAAADwAQCdASoIAAYABABsJZgCdIExGA7pnAAA/uHN2Bv7yjhoofWSRgyTRFe/ZldOPQAAAA==',
    alt: 'An engineer in a hard hat and hi-vis vest holding rolled blueprints at a construction site',
    srcSet: {
      avif: `${wordEngineerAvif160} 160w, ${wordEngineerAvif} 320w`,
      webp: `${wordEngineerWebp160} 160w, ${wordEngineerWebp} 320w`,
    },
  },
  teacher: {
    avif: wordTeacherAvif,
    webp: wordTeacherWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRkAAAABXRUJQVlA4IDQAAACwAQCdASoIAAYABABsJbACdAD52ZqAAP54lf7qxjdtBS8veCnNDy4YMpoDgczL1ahjTAAA',
    alt: 'A teacher standing at a green chalkboard holding a pointer',
    srcSet: {
      avif: `${wordTeacherAvif160} 160w, ${wordTeacherAvif} 320w`,
      webp: `${wordTeacherWebp160} 160w, ${wordTeacherWebp} 320w`,
    },
  },
  doctor: {
    avif: wordDoctorAvif,
    webp: wordDoctorWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJZACdAD0bhXGAAD+11WCG8mfixn0YYjogHStuKiCL98tQAA=',
    alt: 'A doctor in a white coat wearing a stethoscope',
    srcSet: {
      avif: `${wordDoctorAvif160} 160w, ${wordDoctorAvif} 320w`,
      webp: `${wordDoctorWebp160} 160w, ${wordDoctorWebp} 320w`,
    },
  },
  student: {
    avif: wordStudentAvif,
    webp: wordStudentWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJagCdAD0QoEnIAD+ynbN7Emsp63cmWQ2ToGfg8OWuV0AAAA=',
    alt: 'A student carrying a backpack and books outside a school',
    srcSet: {
      avif: `${wordStudentAvif160} 160w, ${wordStudentAvif} 320w`,
      webp: `${wordStudentWebp160} 160w, ${wordStudentWebp} 320w`,
    },
  },
  computer: {
    avif: wordComputerAvif,
    webp: wordComputerWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRj4AAABXRUJQVlA4IDIAAADQAQCdASoIAAYABABsJZgCdAD0SRcpAAD2u+QDgviceHEzrm2Sr9NlqDAkQdpEXzYgAA==',
    alt: 'A desktop computer monitor on a stand',
    srcSet: {
      avif: `${wordComputerAvif160} 160w, ${wordComputerAvif} 320w`,
      webp: `${wordComputerWebp160} 160w, ${wordComputerWebp} 320w`,
    },
  },
  nurse: {
    avif: wordNurseAvif,
    webp: wordNurseWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJagCdADdIye/AAD+12sVcC4Ixw8tBYxlr0L0AdKSO44vQAA=',
    alt: 'A nurse in scrubs and a nurse’s cap holding a clipboard',
    srcSet: {
      avif: `${wordNurseAvif160} 160w, ${wordNurseAvif} 320w`,
      webp: `${wordNurseWebp160} 160w, ${wordNurseWebp} 320w`,
    },
  },
  apple: {
    avif: wordAppleAvif,
    webp: wordAppleWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAADQAQCdASoIAAYABABsJbACdADdL/VwqAD+4lJha5dhA297Tpo31hx85bDCcjEdbfSNRbt1ruAAAA==',
    alt: 'A single red apple with a green leaf',
    srcSet: {
      avif: `${wordAppleAvif160} 160w, ${wordAppleAvif} 320w`,
      webp: `${wordAppleWebp160} 160w, ${wordAppleWebp} 320w`,
    },
  },
  mother: {
    avif: wordMotherAvif,
    webp: wordMotherWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRkAAAABXRUJQVlA4IDQAAADwAQCdASoIAAYABABsJYwCdEf/gbTusoAA/rgGpmMQlIn+f0J1IngNF8RizE5YRCFSuAAA',
    alt: 'A mother holding her young child',
    srcSet: {
      avif: `${wordMotherAvif160} 160w, ${wordMotherAvif} 320w`,
      webp: `${wordMotherWebp160} 160w, ${wordMotherWebp} 320w`,
    },
  },
  father: {
    avif: wordFatherAvif,
    webp: wordFatherWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJQBdgB6XdNTEAAD+4ku/sPwRgpnle6n6vpFggMmCMsCCAAA=',
    alt: 'A smiling father in a navy shirt',
    srcSet: {
      avif: `${wordFatherAvif160} 160w, ${wordFatherAvif} 320w`,
      webp: `${wordFatherWebp160} 160w, ${wordFatherWebp} 320w`,
    },
  },
  brother: {
    avif: wordBrotherAvif,
    webp: wordBrotherWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJYgCdAEf/uZOEAD+64A03MnmECsNcvmDxhJXjrKIaXSCKAA=',
    alt: 'A young boy in a blue t-shirt waving',
    srcSet: {
      avif: `${wordBrotherAvif160} 160w, ${wordBrotherAvif} 320w`,
      webp: `${wordBrotherWebp160} 160w, ${wordBrotherWebp} 320w`,
    },
  },
  sister: {
    avif: wordSisterAvif,
    webp: wordSisterWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAADwAQCdASoIAAYABABsJYgCdIExFco5GoAA/uiMoboRaya7J6GjBudjSTnNAAAA',
    alt: 'A young girl with a ponytail hugging a book',
    srcSet: {
      avif: `${wordSisterAvif160} 160w, ${wordSisterAvif} 320w`,
      webp: `${wordSisterWebp160} 160w, ${wordSisterWebp} 320w`,
    },
  },
  house: {
    avif: wordHouseAvif,
    webp: wordHouseWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAACwAQCdASoIAAYABABsJagAAucXyeTQAP7t1c2B1HHLXX9/Co6MUPSnuAA=',
    alt: 'A house with a terracotta roof, blue front door and a garden path',
    srcSet: {
      avif: `${wordHouseAvif160} 160w, ${wordHouseAvif} 320w`,
      webp: `${wordHouseWebp160} 160w, ${wordHouseWebp} 320w`,
    },
  },
  door: {
    avif: wordDoorAvif,
    webp: wordDoorWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACwAQCdASoIAAYABABsJQBOgB6R/nrwAP7rgDTzP02wxRjw6IbfAdYsWtAngAAA',
    alt: 'A blue arched panel door in a cream frame',
    srcSet: {
      avif: `${wordDoorAvif160} 160w, ${wordDoorAvif} 320w`,
      webp: `${wordDoorWebp160} 160w, ${wordDoorWebp} 320w`,
    },
  },
  chair: {
    avif: wordChairAvif,
    webp: wordChairWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAACQAQCdASoIAAYABABsJQBOgB4/EIgA/u3WATXXy1hJrlbYkGpee74YAAA=',
    alt: 'A wooden chair with a blue upholstered seat',
    srcSet: {
      avif: `${wordChairAvif160} 160w, ${wordChairAvif} 320w`,
      webp: `${wordChairWebp160} 160w, ${wordChairWebp} 320w`,
    },
  },
  book: {
    avif: wordBookAvif,
    webp: wordBookWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRi4AAABXRUJQVlA4ICIAAABwAQCdASoIAAYABABsJYwC7AFAAAD+8K0Os1ENlIBegAAA',
    alt: 'An open book with a blue cover and a ribbon bookmark',
    srcSet: {
      avif: `${wordBookAvif160} 160w, ${wordBookAvif} 320w`,
      webp: `${wordBookWebp160} 160w, ${wordBookWebp} 320w`,
    },
  },
  water: {
    avif: wordWaterAvif,
    webp: wordWaterWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjAAAABXRUJQVlA4ICQAAAAwAQCdASoIAAYABABsJYwAA3AA/vDmSiZWwU3wqA54QH54AAA=',
    alt: 'A glass of clear water with a droplet beside it',
    srcSet: {
      avif: `${wordWaterAvif160} 160w, ${wordWaterAvif} 320w`,
      webp: `${wordWaterWebp160} 160w, ${wordWaterWebp} 320w`,
    },
  },
  bread: {
    avif: wordBreadAvif,
    webp: wordBreadWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRkAAAABXRUJQVlA4IDQAAADQAQCdASoIAAYABABsJZACdAD0U4W0AAD+64VX6K7xOQiY6OxJyMpDAlfDoYYg6aeFzAAA',
    alt: 'A golden loaf of bread with a cut slice and wheat grains',
    srcSet: {
      avif: `${wordBreadAvif160} 160w, ${wordBreadAvif} 320w`,
      webp: `${wordBreadWebp160} 160w, ${wordBreadWebp} 320w`,
    },
  },
  milk: {
    avif: wordMilkAvif,
    webp: wordMilkWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAAAwAQCdASoIAAYABABsJQAAbgAA/vCYgiDsnMuagHh97S7kMEotSHWQOAA=',
    alt: 'A glass of milk beside a milk bottle',
    srcSet: {
      avif: `${wordMilkAvif160} 160w, ${wordMilkAvif} 320w`,
      webp: `${wordMilkWebp160} 160w, ${wordMilkWebp} 320w`,
    },
  },
  tea: {
    avif: wordTeaAvif,
    webp: wordTeaWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAADQAQCdASoIAAYABABsJYgCdAEPAKlUgAD+7WvZ9kRSfeN3U99uyCBFqAA=',
    alt: 'A glass of amber tea on a saucer with fresh mint',
    srcSet: {
      avif: `${wordTeaAvif160} 160w, ${wordTeaAvif} 320w`,
      webp: `${wordTeaWebp160} 160w, ${wordTeaWebp} 320w`,
    },
  },
  car: {
    avif: wordCarAvif,
    webp: wordCarWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjgAAABXRUJQVlA4ICwAAADwAQCdASoIAAYABABsJYwCdIExGBqPToAA/u3rZU0mCQO2qQETfwRyIMpAAA==',
    alt: 'A small blue car on a road',
    srcSet: {
      avif: `${wordCarAvif160} 160w, ${wordCarAvif} 320w`,
      webp: `${wordCarWebp160} 160w, ${wordCarWebp} 320w`,
    },
  },
  cat: {
    avif: wordCatAvif,
    webp: wordCatWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjYAAABXRUJQVlA4ICoAAADQAQCdASoIAAYABABsJQBOgB6WiKoMAAD+8AqQuBpGifXOSNLp0V82AAA=',
    alt: 'A ginger and cream cat sitting with its tail curled',
    srcSet: {
      avif: `${wordCatAvif160} 160w, ${wordCatAvif} 320w`,
      webp: `${wordCatWebp160} 160w, ${wordCatWebp} 320w`,
    },
  },
  bird: {
    avif: wordBirdAvif,
    webp: wordBirdWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjQAAABXRUJQVlA4ICgAAADQAQCdASoIAAYABABsJQBOgCPtrMJDuAD+7dXw34c+XSdLYGkZMhwA',
    alt: 'A small blue songbird perched on a leafy twig',
    srcSet: {
      avif: `${wordBirdAvif160} 160w, ${wordBirdAvif} 320w`,
      webp: `${wordBirdWebp160} 160w, ${wordBirdWebp} 320w`,
    },
  },
  tree: {
    avif: wordTreeAvif,
    webp: wordTreeWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAYABABsJQBOgCP7k+JjgAD+6I/JtdmUU33KpT6lCjmodjS6v1e0oAA=',
    alt: 'A broad green tree on a grassy mound',
    srcSet: {
      avif: `${wordTreeAvif160} 160w, ${wordTreeAvif} 320w`,
      webp: `${wordTreeWebp160} 160w, ${wordTreeWebp} 320w`,
    },
  },
  sun: {
    avif: wordSunAvif,
    webp: wordSunWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjIAAABXRUJQVlA4ICYAAABQAQCdASoIAAYABABsJQBOgCgAAP7wvZIuP6C/C4saPxH/ElygAA==',
    alt: 'A golden sun with rays behind a small white cloud',
    srcSet: {
      avif: `${wordSunAvif160} 160w, ${wordSunAvif} 320w`,
      webp: `${wordSunWebp160} 160w, ${wordSunWebp} 320w`,
    },
  },
  moon: {
    avif: wordMoonAvif,
    webp: wordMoonWebp,
    width: 320,
    height: 240,
    lqip: 'data:image/webp;base64,UklGRjAAAABXRUJQVlA4ICQAAACwAQCdASoIAAYABABsJQBOgCHfwHkAAP7v/WLTum1l9aA0AAA=',
    alt: 'A crescent moon with small stars and a cloud',
    srcSet: {
      avif: `${wordMoonAvif160} 160w, ${wordMoonAvif} 320w`,
      webp: `${wordMoonWebp160} 160w, ${wordMoonWebp} 320w`,
    },
  },
};

/* ------------------------------------------------------- illustrations --- */

export const illustrations = {
  emptySearch: { src: emptySearchSrc, width: 240, height: 180, alt: 'No words match your search' },
  emptyBookmarks: {
    src: emptyBookmarksSrc,
    width: 240,
    height: 180,
    alt: 'You have not saved any words yet',
  },
  emptyProgress: {
    src: emptyProgressSrc,
    width: 240,
    height: 180,
    alt: 'No learning progress recorded yet',
  },
  errorGeneric: { src: errorGenericSrc, width: 240, height: 180, alt: 'Something went wrong' },
  offline: { src: offlineSrc, width: 240, height: 180, alt: 'You are offline' },
  notFound: { src: notFoundSrc, width: 240, height: 180, alt: 'This page could not be found' },
  quizComplete: {
    src: quizCompleteSrc,
    width: 240,
    height: 180,
    alt: 'Quiz complete — a trophy surrounded by confetti',
  },
} as const satisfies Record<string, VectorAsset>;

export const decorative = {
  leafFlourish: { src: leafFlourishSrc, width: 120, height: 120, alt: '', decorative: true },
  quoteBlob: { src: quoteBlobSrc, width: 220, height: 160, alt: '', decorative: true },
  heroGradientOverlay: {
    src: heroGradientOverlaySrc,
    width: 1600,
    height: 900,
    alt: '',
    decorative: true,
  },
  patternTile: { src: patternTileSrc, width: 80, height: 80, alt: '', decorative: true },
} as const satisfies Record<string, VectorAsset>;

/* ------------------------------------------------------------- sounds --- */

export const sounds = {
  correct: { src: correctSrc, label: 'Correct answer', durationMs: 480 },
  incorrect: { src: incorrectSrc, label: 'Incorrect answer', durationMs: 380 },
  complete: { src: completeSrc, label: 'Quiz complete', durationMs: 480 },
} as const satisfies Record<string, SoundAsset>;

/* ------------------------------------------------------------ lookups --- */

/**
 * Artwork for a word, or `undefined` when the word is not in the illustrated
 * subset — render the designed gradient tile instead.
 */
export function getWordArt(wordId: string): ImageAsset | undefined {
  return wordArt[wordId];
}

/**
 * Artwork for a category, or `undefined` when the category has no illustration
 * — render the designed gradient tile instead.
 */
export function getCategoryArt(categoryId: string): ImageAsset | undefined {
  return categoryArt[categoryId];
}

/** `true` when `wordId` has a real illustration. Narrows to `WordArtId`. */
export function hasWordArt(wordId: string): wordId is WordArtId {
  return wordId in wordArt;
}

/** `true` when `categoryId` has a real illustration. Narrows to `CategoryArtId`. */
export function hasCategoryArt(categoryId: string): categoryId is CategoryArtId {
  return categoryId in categoryArt;
}
