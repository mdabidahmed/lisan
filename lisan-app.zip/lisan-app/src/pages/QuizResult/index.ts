export { QuizResultPage } from './QuizResult';
