export { WordDetailPage } from './WordDetail';
