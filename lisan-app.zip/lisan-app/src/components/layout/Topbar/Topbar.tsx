import { useCallback, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

import { Logo } from '@/components/brand/Logo';
import { Avatar } from '@/components/ui/Avatar';
import { IconButton } from '@/components/ui/IconButton';
import { SearchBox } from '@/components/ui/SearchBox';
import { DEFAULT_PROFILE } from '@/constants/app';
import { TOPBAR_NAV } from '@/constants/navigation';
import { ROUTES } from '@/constants/routes';
import { cn } from '@/utils/cn';

import { FontSwitcher } from './FontSwitcher';
import { ThemeToggle } from './ThemeToggle';
import styles from './Topbar.module.css';

export interface TopbarProps {
  onOpenMenu: () => void;
}

/**
 * Secondary navigation, global search, theme and profile (product spec §8).
 * Deliberately sparse — the sidebar carries primary navigation.
 */
export function Topbar({ onOpenMenu }: TopbarProps) {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  const runSearch = useCallback(
    (value: string) => {
      const trimmed = value.trim();
      if (!trimmed) return;
      void navigate(`${ROUTES.vocabulary}?q=${encodeURIComponent(trimmed)}`);
    },
    [navigate],
  );

  return (
    <header className={styles.topbar}>
      <div className={styles.start}>
        <IconButton
          icon="vocabulary"
          label="Open navigation menu"
          variant="ghost"
          className={styles.menuButton}
          onClick={onOpenMenu}
        />
        <span className={styles.mobileBrand}>
          <Logo compact size={28} />
        </span>

        <nav className={styles.nav} aria-label="Sections">
          <ul className={styles.navList}>
            {TOPBAR_NAV.map((item) => (
              <li key={item.id}>
                <NavLink
                  to={item.to}
                  end={item.end ?? false}
                  className={({ isActive }) => cn(styles.navLink, isActive && styles.navLinkActive)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className={styles.end}>
        <SearchBox
          value={query}
          onValueChange={setQuery}
          onSubmit={runSearch}
          placeholder="Search anything..."
          label="Search vocabulary"
          className={styles.search}
        />
        <FontSwitcher />
        <ThemeToggle />
        <Avatar name={DEFAULT_PROFILE.name} />
      </div>
    </header>
  );
}
