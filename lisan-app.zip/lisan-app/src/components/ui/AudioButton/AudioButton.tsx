import type { MouseEvent } from 'react';

import { IconButton } from '@/components/ui/IconButton';
import { useAudio } from '@/hooks';
import { cn } from '@/utils';

import styles from './AudioButton.module.css';

export interface AudioButtonProps {
  text: string;
  size?: 'sm' | 'md' | 'lg' | undefined;
  variant?: 'primary' | 'soft' | 'ghost' | undefined;
  label?: string | undefined;
  rate?: number | undefined;
  className?: string | undefined;
  onPlay?: (() => void) | undefined;
  /** Defaults to true so the button works inside clickable rows and cards. */
  stopPropagation?: boolean | undefined;
}

const UNSUPPORTED_TITLE = 'Speech synthesis is not available in this browser';

/**
 * The single entry point for pronunciation in the product. Every other component asks for audio by
 * rendering this, which keeps `useAudio` (and therefore the speech queue) owned by one place.
 */
export function AudioButton({
  text,
  size = 'md',
  variant = 'primary',
  label,
  rate,
  className,
  onPlay,
  stopPropagation = true,
}: AudioButtonProps) {
  const { speak, stop, isSpeaking, isSupported, activeText } = useAudio();
  const isPlaying = isSpeaking && activeText === text;

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    if (stopPropagation) event.stopPropagation();
    if (!isSupported) return;

    if (isPlaying) {
      stop();
      return;
    }
    speak(text, rate === undefined ? undefined : { rate });
    onPlay?.();
  };

  const accessibleLabel = label ?? (isPlaying ? 'Stop pronunciation' : 'Play pronunciation');

  // A disabled button fires no pointer events, so the "why" has to live on the wrapper.
  return (
    <span
      className={cn(styles.root, className)}
      data-playing={isPlaying}
      {...(isSupported ? {} : { title: UNSUPPORTED_TITLE })}
    >
      <IconButton
        icon={isPlaying ? 'pause' : 'play'}
        label={accessibleLabel}
        variant={variant}
        size={size}
        shape="circle"
        className={styles.button}
        disabled={!isSupported}
        onClick={handleClick}
      />
      <span aria-live="polite" className="u-visually-hidden">
        {isPlaying ? 'Playing pronunciation' : ''}
      </span>
    </span>
  );
}
