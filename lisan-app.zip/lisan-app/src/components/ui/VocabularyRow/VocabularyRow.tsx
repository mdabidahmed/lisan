import type { MouseEvent } from 'react';

import { Icon } from '@/components/icons';
import { AudioButton } from '@/components/ui/AudioButton';
import { IconButton } from '@/components/ui/IconButton';
import { WordThumbnail } from '@/components/ui/WordThumbnail';
import { ARABIC_CONTENT_ATTRS } from '@/i18n';
import type { VocabularyWord } from '@/types';
import { cn } from '@/utils';

import styles from './VocabularyRow.module.css';

export interface VocabularyRowProps {
  word: VocabularyWord;
  categoryName?: string | undefined;
  bookmarked?: boolean | undefined;
  onOpen: (word: VocabularyWord) => void;
  onToggleBookmark?: ((word: VocabularyWord) => void) | undefined;
  showChevron?: boolean | undefined;
  className?: string | undefined;
}

/**
 * Vocabulary list item (reference screen 2).
 *
 * The whole row is clickable, but the click target is a real `<button>` stretched over the row by
 * its `::after`. That keeps one tab stop and real keyboard semantics while leaving the audio and
 * bookmark controls as independent buttons layered above it.
 */
export function VocabularyRow({
  word,
  categoryName,
  bookmarked = false,
  onOpen,
  onToggleBookmark,
  showChevron = false,
  className,
}: VocabularyRowProps) {
  const handleBookmark = (event: MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    onToggleBookmark?.(word);
  };

  return (
    <div className={cn(styles.row, className)}>
      <WordThumbnail
        wordId={word.id}
        arabic={word.arabic}
        size={64}
        className={styles.thumbnail}
        {...(word.image === undefined ? {} : { src: word.image })}
      />

      <button
        type="button"
        className={styles.primary}
        onClick={() => {
          onOpen(word);
        }}
      >
        <span className={styles.arabic} {...ARABIC_CONTENT_ATTRS}>
          {word.arabic}
        </span>
        <span className={styles.transliteration}>{word.transliteration}</span>
        <span className={styles.meaning}>{word.english}</span>
        {categoryName === undefined ? null : (
          <span className={styles.category}>{categoryName}</span>
        )}
      </button>

      <div className={styles.actions}>
        <AudioButton text={word.arabic} variant="primary" size="md" />
        {onToggleBookmark === undefined ? null : (
          <IconButton
            icon="favorite"
            label={
              bookmarked ? `Remove ${word.english} from bookmarks` : `Bookmark ${word.english}`
            }
            variant="soft"
            shape="circle"
            size="md"
            active={bookmarked}
            onClick={handleBookmark}
          />
        )}
        {showChevron ? <Icon name="chevron-right" size={18} className={styles.chevron} /> : null}
      </div>
    </div>
  );
}
