import { cloneElement, useId, type ReactElement } from 'react';

import { cn } from '@/utils';

import styles from './Tooltip.module.css';

export type TooltipPlacement = 'top' | 'bottom' | 'start' | 'end';

export interface TooltipProps {
  content: string;
  placement?: TooltipPlacement | undefined;
  /** Exactly one focusable child — hover and keyboard focus both reveal the bubble. */
  children: ReactElement;
  className?: string | undefined;
}

type DescribableElement = ReactElement<{ 'aria-describedby'?: string | undefined }>;

const PLACEMENT_CLASS: Record<TooltipPlacement, string | undefined> = {
  top: styles.top,
  bottom: styles.bottom,
  start: styles.start,
  end: styles.end,
};

/**
 * Deliberately CSS-only: no portal, no positioning engine, no state. Hover and `:focus-within` on
 * the wrapper reveal the bubble, and `aria-describedby` keeps the text available to assistive
 * technology whether or not it is visible.
 */
export function Tooltip({ content, placement = 'top', children, className }: TooltipProps) {
  const tooltipId = useId();
  const trigger = cloneElement(children as DescribableElement, {
    'aria-describedby': tooltipId,
  });

  return (
    <span className={cn(styles.wrapper, PLACEMENT_CLASS[placement], className)}>
      {trigger}
      <span className={styles.bubble} id={tooltipId} role="tooltip">
        {content}
      </span>
    </span>
  );
}
