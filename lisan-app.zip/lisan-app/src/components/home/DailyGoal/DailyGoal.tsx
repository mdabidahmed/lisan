import { Icon } from '@/components/icons';
import { Card } from '@/components/ui/Card';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { clampPercent } from '@/utils/format';

import styles from './DailyGoal.module.css';

export interface DailyGoalProps {
  /** Words learned today. */
  current: number;
  /** The learner's daily target. */
  target: number;
  title?: string;
  description?: string;
}

/** "Today's Goal" card (reference screen 1). */
export function DailyGoal({
  current,
  target,
  title = "Today's Goal",
  description,
}: DailyGoalProps) {
  const safeTarget = Math.max(1, target);
  const percent = clampPercent((current / safeTarget) * 100);
  const caption = description ?? `Learn ${target} new words`;

  return (
    <Card padding="md">
      <div className={styles.row}>
        <span className={styles.badge}>
          <Icon name="goal" size={22} />
        </span>
        <div className={styles.copy}>
          <h3 className={styles.title}>{title}</h3>
          <p className={styles.caption}>{caption}</p>
          <div className={styles.bar}>
            <ProgressBar
              value={percent}
              ariaLabel={`Daily goal: ${current} of ${target} words`}
              showValue
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
