import { Icon } from '@/components/icons';
import { Card } from '@/components/ui/Card';

import styles from './ReminderCard.module.css';

export interface ReminderCardProps {
  title?: string;
  description?: string;
}

/** "Daily Reminder" encouragement card (reference screen 1). */
export function ReminderCard({
  title = 'Daily Reminder',
  description = 'A little progress each day leads to big results.',
}: ReminderCardProps) {
  return (
    <Card padding="md" className={styles.card}>
      <div className={styles.row}>
        <span className={styles.badge}>
          <Icon name="study-time" size={22} />
        </span>
        <div className={styles.copy}>
          <h3 className={styles.title}>{title}</h3>
          <p className={styles.description}>{description}</p>
        </div>
      </div>
      <span className={styles.leaf} aria-hidden="true">
        <Icon name="nature" size={72} />
      </span>
    </Card>
  );
}
