import { AudioButton } from '@/components/ui/AudioButton';
import { QuizOption, type QuizOptionState } from '@/components/ui/QuizOption';
import type { PracticeDirection } from '@/data/practiceModes';
import type { AnswerVerdict } from '@/features/practice/answerCheck';
import { ARABIC_CONTENT_ATTRS } from '@/i18n';
import type { QuizQuestion } from '@/types/quiz';

import { QuizFeedback, QuizNav, QuizShell } from '../QuizShell';

import styles from './QuizCard.module.css';

export interface QuizCardProps {
  question: QuizQuestion;
  questionNumber: number;
  totalQuestions: number;
  /**
   * Which way round the question is asked. `arabic-to-english` prints the Arabic prompt large
   * and reads it aloud; `english-to-arabic` prints the English and offers Arabic options.
   */
  direction?: PracticeDirection | undefined;
  selectedAnswer?: string | undefined;
  /** After submission the correct/incorrect styling is revealed. */
  revealed?: boolean;
  onSelect: (value: string) => void;
  onNext?: (() => void) | undefined;
  onPrevious?: (() => void) | undefined;
  canGoBack?: boolean;
  isLast?: boolean;
  /** Listening questions: the script stays hidden until the answer is revealed. */
  concealPrompt?: boolean | undefined;
  /** Overrides the instruction line. */
  prompt?: string | undefined;
}

const DEFAULT_PROMPT: Record<PracticeDirection, string> = {
  'arabic-to-english': 'Select the correct meaning:',
  'english-to-arabic': 'Select the correct Arabic word:',
};
const LISTENING_PROMPT = 'Listen to the word, then select its meaning:';

function optionState(
  option: string,
  {
    selectedAnswer,
    revealed,
    correctAnswer,
  }: Pick<QuizCardProps, 'selectedAnswer' | 'revealed'> & {
    correctAnswer: string;
  },
): QuizOptionState {
  if (!revealed) return option === selectedAnswer ? 'selected' : 'default';
  if (option === correctAnswer) return 'correct';
  if (option === selectedAnswer) return 'incorrect';
  return 'default';
}

/**
 * One question at a time, large Arabic, large answer targets (product spec §50).
 *
 * Covers both option-picking types and both directions. For listening the audio *is* the
 * question, so the script is masked until the reveal and playback is always learner-initiated —
 * iOS Safari refuses speech that did not come from a gesture, and autoplay would be the wrong
 * default regardless.
 */
export function QuizCard({
  question,
  questionNumber,
  totalQuestions,
  direction = 'arabic-to-english',
  selectedAnswer,
  revealed = false,
  onSelect,
  onNext,
  onPrevious,
  canGoBack = false,
  isLast = false,
  concealPrompt = false,
  prompt,
}: QuizCardProps) {
  const options = question.options ?? [];
  const concealed = concealPrompt && !revealed;
  const arabicPrompt = direction === 'arabic-to-english';
  const verdict: AnswerVerdict | null = revealed
    ? selectedAnswer === question.correctAnswer
      ? 'correct'
      : 'incorrect'
    : null;

  return (
    <QuizShell
      questionNumber={questionNumber}
      totalQuestions={totalQuestions}
      prompt={prompt ?? (concealPrompt ? LISTENING_PROMPT : DEFAULT_PROMPT[direction])}
    >
      <div className={styles.subject}>
        {concealed ? (
          <span className={styles.concealed} aria-hidden="true" />
        ) : (
          <span
            className={arabicPrompt ? styles.arabic : styles.english}
            {...(arabicPrompt ? ARABIC_CONTENT_ATTRS : {})}
          >
            {question.question}
          </span>
        )}
        {/* Reading a production prompt aloud would be reading out its answer. */}
        {arabicPrompt ? (
          <AudioButton
            text={question.question}
            size={concealPrompt ? 'lg' : 'md'}
            variant="primary"
            label={concealPrompt ? 'Play the word again' : 'Play the word'}
            className={styles.audio}
          />
        ) : null}
      </div>

      {concealed ? <p className={styles.hint}>Tap play as many times as you need.</p> : null}

      <div className={styles.options} role="radiogroup" aria-label="Answer options">
        {options.map((option, index) => (
          <QuizOption
            key={option}
            value={option}
            label={option}
            shortcut={String(index + 1)}
            arabic={!arabicPrompt}
            className={arabicPrompt ? undefined : styles.arabicOption}
            state={optionState(option, {
              ...(selectedAnswer === undefined ? {} : { selectedAnswer }),
              revealed,
              correctAnswer: question.correctAnswer,
            })}
            disabled={revealed}
            onSelect={onSelect}
          />
        ))}
      </div>

      <QuizFeedback
        revealed={revealed}
        verdict={verdict}
        correctAnswer={question.correctAnswer}
        arabic={!arabicPrompt}
      />

      <QuizNav
        onNext={onNext}
        onPrevious={onPrevious}
        canGoBack={canGoBack}
        isLast={isLast}
        nextDisabled={!revealed}
      />
    </QuizShell>
  );
}
